<?php
/**
 * Created by PhpStorm.
 * User: Waqas Riaz
 * Date: 22/12/16
 * Time: 5:15 PM
 * Since v1.5.0
 */
get_header();

get_template_part("template-parts/common-taxonomy");

get_footer();