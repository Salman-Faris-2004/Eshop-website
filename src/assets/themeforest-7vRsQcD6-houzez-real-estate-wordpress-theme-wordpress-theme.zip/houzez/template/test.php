<?php
/**
 * Template Name: Testing
 * Created by PhpStorm.
 * User: waqasriaz
 * Date: 16/13/15
 * Time: 3:27 PM
 */
get_header();

// functions.php or custom plugin file




get_footer(); ?>