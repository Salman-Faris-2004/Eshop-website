<div class="hz-loading-dots houzez-loader-js">
    <span></span><span></span><span></span>
</div>