<?php

/**
 * Template Post Type: Houzez Builder
 *
 * @package Houzez
 */
get_template_part( 'template-post', houzez_tb_get_template_type(get_the_ID()) );