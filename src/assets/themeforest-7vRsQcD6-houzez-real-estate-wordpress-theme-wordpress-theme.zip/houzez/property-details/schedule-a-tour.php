<div class="property-schedule-tour-wrap property-section-wrap" id="property-schedule-tour-wrap">
	<div class="block-wrap">
		<div class="block-title-wrap d-flex justify-content-between align-items-center">
			<h2><?php echo houzez_option('sps_schedule_tour', 'Schedule a Tour'); ?></h2>
		</div><!-- block-title-wrap -->
		<div class="block-content-wrap">
			<?php get_template_part('property-details/partials/schedule-tour-form'); ?>
		</div><!-- block-content-wrap -->
	</div><!-- block-wrap -->
</div><!-- property-schedule-tour-wrap -->