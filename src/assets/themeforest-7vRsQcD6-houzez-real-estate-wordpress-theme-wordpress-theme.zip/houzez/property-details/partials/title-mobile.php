<div class="page-title">
	<span class="item-title property-title-mobile"><?php the_title(); ?></span>
</div><!-- page-title -->